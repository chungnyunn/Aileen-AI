package com.aaanan.aileen

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val requestCode = 41
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
            setBackgroundColor(0xFFFFF7FF.toInt())
        }
        root.addView(TextView(this).apply {
            text = "Aileen 💗\nAsisten virtual Aa Anan"
            textSize = 26f; gravity = Gravity.CENTER; setTextColor(0xFF57345F.toInt())
        })
        root.addView(TextView(this).apply {
            text = "Versi awal: tampilkan Aileen mengambang dan uji panggilan suara saat layanan aktif."
            textSize = 16f; gravity = Gravity.CENTER; setPadding(0, 24, 0, 24)
        })
        root.addView(Button(this).apply { text = "Izinkan tampilan mengambang"; setOnClickListener { askOverlay() } })
        root.addView(Button(this).apply { text = "Tampilkan Aileen"; setOnClickListener { showAileen() } })
        root.addView(Button(this).apply { text = "Mulai dengarkan 'Aileen'"; setOnClickListener { startListeningService() } })
        root.addView(Button(this).apply { text = "Hentikan layanan suara"; setOnClickListener { stopService(Intent(this@MainActivity, AileenService::class.java)) } })
        setContentView(root)
    }

    private fun askOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } else Toast.makeText(this, "Izin tampilan mengambang sudah aktif", Toast.LENGTH_SHORT).show()
    }
    private fun showAileen() {
        if (!Settings.canDrawOverlays(this)) { askOverlay(); return }
        startService(Intent(this, AileenService::class.java).setAction(AileenService.ACTION_SHOW))
    }
    private fun startListeningService() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), requestCode); return
        }
        if (!Settings.canDrawOverlays(this)) { askOverlay(); return }
        startService(Intent(this, AileenService::class.java).setAction(AileenService.ACTION_LISTEN))
        Toast.makeText(this, "Layanan suara dimulai. Notifikasi akan tetap terlihat.", Toast.LENGTH_LONG).show()
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, results)
        if (requestCode == this.requestCode && results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED) startListeningService()
    }
}
