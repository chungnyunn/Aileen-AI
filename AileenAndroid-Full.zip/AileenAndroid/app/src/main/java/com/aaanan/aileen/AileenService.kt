package com.aaanan.aileen

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.*
import android.widget.ImageView
import android.widget.TextView
import java.util.Locale

class AileenService : Service(), TextToSpeech.OnInitListener {
    companion object {
        const val ACTION_SHOW = "aileen.SHOW"
        const val ACTION_LISTEN = "aileen.LISTEN"
        private const val CHANNEL = "aileen_voice"
        private const val NOTIFICATION_ID = 7
    }
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var listening = false
    private var restarting = false

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        tts = TextToSpeech(this, this)
        createChannel()
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_SHOW -> showCharacter()
            ACTION_LISTEN -> { startForeground(NOTIFICATION_ID, notification()); listening = true; showCharacter(); beginRecognition() }
        }
        return START_STICKY
    }
    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL, "Aileen - mikrofon aktif", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }
    private fun notification(): Notification {
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        return b.setContentTitle("Aileen sedang mendengarkan")
            .setContentText("Mikrofon aktif untuk mendeteksi panggilan 'Aileen'. Ketuk untuk membuka aplikasi.")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentIntent(pi).build()
    }
    private fun showCharacter() {
        if (bubble != null) return
        val container = android.widget.FrameLayout(this)
        val image = ImageView(this).apply {
            setImageResource(R.drawable.aileen_avatar)
            scaleType = ImageView.ScaleType.CENTER_CROP
            contentDescription = "Aileen, asisten Aa Anan"
        }
        container.addView(image, android.widget.FrameLayout.LayoutParams(300, 430))
        val greeting = TextView(this).apply {
            text = "Halo Aa Anan! 💗"
            textSize = 16f; setTextColor(0xFFFFFFFF.toInt()); setBackgroundColor(0xCC75449A.toInt()); setPadding(14, 8, 14, 8)
        }
        val lp = android.widget.FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        container.addView(greeting, lp)
        val params = WindowManager.LayoutParams(300, 430, if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
        params.gravity = Gravity.BOTTOM or Gravity.RIGHT
        params.x = 8; params.y = 100
        container.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
            override fun onTouch(v: View, e: android.view.MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=params.x; oy=params.y; return true }
                    MotionEvent.ACTION_MOVE -> { params.x=ox-(e.rawX-sx).toInt(); params.y=oy-(e.rawY-sy).toInt(); wm.updateViewLayout(container, params); return true }
                    MotionEvent.ACTION_UP -> { if (kotlin.math.abs(e.rawX-sx)<8 && kotlin.math.abs(e.rawY-sy)<8) speak("Iya, Aa Anan. Aileen di sini. Ada yang bisa Aileen bantu?"); return true }
                }
                return false
            }
        })
        bubble = container
        try { wm.addView(container, params) } catch (_: Exception) { bubble = null }
    }
    private fun beginRecognition() {
        if (!listening || !SpeechRecognizer.isRecognitionAvailable(this)) return
        if (recognizer == null) recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: android.os.Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { restartSoon() }
            override fun onResults(results: android.os.Bundle?) {
                val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                if (words.any { it.lowercase(Locale("id", "ID")).contains("aileen") || it.lowercase().contains("ailin") }) {
                    showCharacter(); speak("Iya, Aa Anan. Aileen di sini. Ada yang bisa Aileen bantu?")
                }
                restartSoon()
            }
            override fun onPartialResults(partialResults: android.os.Bundle?) {
                val words = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                if (words.any { it.lowercase().contains("aileen") || it.lowercase().contains("ailin") }) {
                    showCharacter(); speak("Iya, Aa Anan. Aileen di sini.")
                }
            }
            override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        try { recognizer?.startListening(i) } catch (_: Exception) { restartSoon() }
    }
    private fun restartSoon() {
        if (!listening || restarting) return
        restarting = true
        android.os.Handler(mainLooper).postDelayed({ restarting = false; if (listening) beginRecognition() }, 1200)
    }
    private fun speak(text: String) { tts?.language = Locale("id", "ID"); tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "aileen_reply") }
    override fun onInit(status: Int) { if (status == TextToSpeech.SUCCESS) tts?.language = Locale("id", "ID") }
    override fun onDestroy() {
        listening = false
        try { recognizer?.destroy() } catch (_: Exception) {}
        tts?.shutdown()
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
